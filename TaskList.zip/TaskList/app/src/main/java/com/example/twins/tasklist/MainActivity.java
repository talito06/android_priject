package com.example.twins.tasklist;

import android.content.Intent;
import android.support.design.widget.TabItem;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MyActivity";

    // VARIABLES //
    private Toolbar toolbar;
    private TabLayout tabLayout;
    private TabItem tab1;
    private TabItem tab2;
    private PagerAdapter pagerAdapter;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );

        Toolbar toolbar = (Toolbar) findViewById( R.id.toolbar );
        setSupportActionBar( toolbar );



        // Create an instance of the tab layout from the view.
        tabLayout = findViewById( R.id.tabLayout );
        tab1 = findViewById( R.id.tab1 );
        tab2 = findViewById( R.id.tab2 );
        viewPager = findViewById( R.id.pager );

        pagerAdapter = new PagerAdapter( getSupportFragmentManager(), tabLayout.getTabCount() );
        viewPager.setAdapter( pagerAdapter );

        //Set the tabs to fill the entire layout.
        tabLayout.setTabGravity( TabLayout.GRAVITY_FILL );

        // Using PagerAdapter to manage page views in fragments.
        // Each page is represented by its own fragment.
        // This is another example of the adapter pattern

        // Setting a listener for clicks.

        //viewPager.addOnPageChangeListener( new TabLayout.TabLayoutOnPageChangeListener( tabLayout ) );

        tabLayout.setOnTabSelectedListener( new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager.setCurrentItem( tab.getPosition() );
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        } );

        viewPager.addOnPageChangeListener( new TabLayout.TabLayoutOnPageChangeListener( tabLayout ) );
    }
}

/*
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate( R.menu.menu_main, menu );
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.action_add:
                Log.d( TAG, "The adding icon was pressed" );
                Intent intent = new Intent( this, Main2Activity.class );
                startActivity( intent );
                displayToast( getString( R.string.action_order_message ) );
                return true;
            case R.id.ic_action_delete:
                Log.d( TAG, "The delete icon have been pressed" );

                displayToast( getString( R.string.action_status_message ) );
                return true;
//            case R.id.ic_action_clear:
//                Log.d( TAG, "The clear icon have been pressed" );
//
//                displayToast( getString( R.string.action_status_message ) );
//                return true;
//            case R.id.ic_action_check:
//                Log.d( TAG, "The clear icon have been pressed" );
//
//                displayToast( getString( R.string.action_status_message ) );
//                return true;


            default:
        }
        return super.onOptionsItemSelected( item );

    }


    private void displayToast(String message) {
        Toast.makeText( getApplicationContext(), message,
                Toast.LENGTH_SHORT ).show();

    }


*/